
export default function ReviewsBadge(){
  return (
    <div className="google-badge">
      {/* Placeholder for Google Reviews widget */}
      <div className="bg-white rounded-xl shadow-card px-4 py-3 flex items-center gap-3">
        <div className="w-6 h-6 rounded-full overflow-hidden">
          <div className="w-6 h-6 bg-gradient-to-br from-red-500 to-yellow-400 rounded-full"></div>
        </div>
        <div className="text-sm">
          <div className="font-semibold">5.0 ★★★★★</div>
          <div className="text-[11px] text-black/60">2 REVIEWS</div>
        </div>
      </div>
    </div>
  )
}
