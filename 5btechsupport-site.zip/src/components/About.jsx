
export default function About(){
  return (
    <section className="mt-24">
      <div className="relative">
        <div className="absolute inset-0 -z-10 bg-[url('https://images.unsplash.com/photo-1501785888041-af3ef285b470?q=80&w=1600&auto=format&fit=crop')] bg-cover bg-center brightness-[.55]"></div>
        <div className="container-5b py-20 md:py-28">
          <div className="bg-white rounded-2xl p-8 md:p-12 shadow-card max-w-5xl">
            <h3 className="text-4xl font-extrabold mb-6">About Us</h3>
            <div className="grid md:grid-cols-[1.2fr,0.8fr] gap-8 items-start">
              <div className="space-y-5 text-black/85 leading-7">
                <p>
                  5B Tech Support is a locally owned tech support business based in Hailey, Idaho, founded and operated by Alexander Ybaben,
                  a senior at The Sage School. With a passion for technology and a commitment to helping the community, Alexander started 5B Tech Support to
                  provide clear, reliable, and affordable tech help to residents of the Wood River Valley.
                </p>
                <p>
                  Working alongside him is Ozzy Coghlan, a trusted team member who brings strong technical skills and a friendly approach to every job.
                  Together, they offer a wide range of services — from smart home setup and software support to cloud transfers and malware protection — all delivered
                  with patience, professionalism, and a personal touch.
                </p>
                <a href="/about" className="inline-flex items-center gap-2 text-white bg-brand px-5 py-3 rounded-lg font-medium w-fit hover:bg-brand-dark">Learn More</a>
              </div>
              <div className="flex flex-col gap-6">
                <div className="w-[260px] h-[260px] bg-[url('https://images.unsplash.com/photo-1502685104226-ee32379fefbe?q=80&w=800&auto=format&fit=crop')] bg-cover bg-center blob mx-auto"></div>
                <div className="w-[260px] h-[260px] bg-[url('https://images.unsplash.com/photo-1494790108377-be9c29b29330?q=80&w=800&auto=format&fit=crop')] bg-cover bg-center blob-2 mx-auto"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
