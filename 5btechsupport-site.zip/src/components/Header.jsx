
import { Link, NavLink } from 'react-router-dom'

export default function Header(){
  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur border-b border-black/5">
      <div className="container-5b flex items-center justify-between py-4">
        <Link to="/" className="flex items-center gap-2 select-none">
          {/* Text logo to match screenshot; replace with your SVG/PNG later */}
          <div className="flex items-baseline gap-1 font-display">
            <span className="text-[28px] leading-none font-extrabold text-brand">5B</span>
            <div className="flex flex-col leading-[0.9]">
              <span className="text-[18px] font-bold tracking-wide text-brand">TECH</span>
              <span className="text-[18px] font-bold tracking-wide text-brand">SUPPORT</span>
            </div>
          </div>
        </Link>
        <nav className="hidden md:flex items-center gap-10 font-medium">
          <NavLink className="nav-link" to="/">home</NavLink>
          <NavLink className="nav-link" to="/pricing">pricing</NavLink>
          <NavLink className="nav-link" to="/about">about</NavLink>
          <NavLink className="nav-link" to="/book">book</NavLink>
        </nav>
      </div>
    </header>
  )
}
