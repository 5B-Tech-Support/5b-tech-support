
export default function Hero(){
  return (
    <section className="pt-24 md:pt-40">
      <div className="container-5b">
        <div className="relative mx-auto max-w-3xl text-center">
          <div className="absolute -top-10 -left-10 right-0 mx-auto -z-10 h-[280px] md:h-[340px] bg-brand.light text-brand/20 blob"></div>
          <h1 className="font-display text-4xl md:text-5xl font-extrabold text-brand mt-24">5B Tech Support</h1>
          <div className="mx-auto mt-3 w-40 h-[2px] bg-brand/30"></div>
          <p className="mt-6 text-lg md:text-xl text-black/80">Tech made simple, at your door.</p>
        </div>
      </div>
    </section>
  )
}
