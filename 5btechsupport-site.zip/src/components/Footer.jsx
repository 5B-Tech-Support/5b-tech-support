
export default function Footer(){
  return (
    <footer className="mt-24 border-t border-black/5">
      <div className="container-5b py-12 text-center space-y-6">
        <div className="text-sm text-black/70">&copy; 2025 5B Tech Support LLC</div>
        <div className="text-sm">
          <a href="#" className="underline">Terms &amp; Conditions</a>
        </div>
        <div className="font-medium space-y-1">
          <div><a href="mailto:info@5BTechSupport.com">info@5BTechSupport.com</a></div>
          <div>(208) 727-7510</div>
        </div>
      </div>
    </footer>
  )
}
