
const items = [
  {
    title: 'Tech Fixes & Support',
    body: `From stubborn software issues to syncing problems, we solve the day-to-day tech headaches that slow you down.
Our Software Support, Malware Protection, and Mobile Phone Optimization services keep your devices running smoothly and securely.`
  },
  {
    title: 'Setup & Organization',
    body: `Getting started or feeling disorganized? We help with Device Setup, File Organization, and Cloud Transfers so your digital world is clean, connected, and clutter-free — whether you're switching devices or just need a fresh start.`
  },
  {
    title: 'Personal Guidance',
    body: `Need advice or want to feel more confident with your tech? Our Product Consultation and 1-on-1 Software Training services are built to empower you — with clear guidance, smart recommendations, and real results.`
  }
]

export default function Services(){
  return (
    <section className="mt-16 md:mt-24">
      <div className="bg-brand.light/60 py-16">
        <div className="container-5b">
          <h3 className="text-4xl font-extrabold text-center mb-3">Our Services</h3>
          <p className="text-center text-black/70 mb-12">Some things we offer. Learn more on the <span className="italic">Services</span> page.</p>
          <div className="grid md:grid-cols-3 gap-14">
            {items.map((it, idx) => (
              <div key={idx} className="text-center px-4">
                <div className="w-16 h-16 mx-auto rounded-full bg-black/20 mb-6"></div>
                <h4 className="text-xl font-semibold mb-3">{it.title}</h4>
                <p className="text-black/80 leading-7">{it.body}</p>
              </div>
            ))}
          </div>
          <div className="mt-12 text-center">
            <a href="/services" className="inline-flex items-center gap-2 px-6 py-3 rounded-lg border border-brand text-brand font-medium bg-white hover:bg-brand.light">All Services</a>
          </div>
        </div>
      </div>
    </section>
  )
}
