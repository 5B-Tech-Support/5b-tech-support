
export default function Mission(){
  return (
    <section className="mt-28">
      <div className="container-5b">
        <div className="mx-auto max-w-5xl bg-brand.light rounded-3xl p-8 md:p-14 text-center shadow-card">
          <h3 className="text-3xl font-semibold mb-6">Our Mission</h3>
          <p className="text-lg leading-8 text-black/80 max-w-3xl mx-auto">
            At 5B Tech Support, our mission is to make reliable, in-home tech help easy and accessible. We specialize in software support,
            troubleshooting, and solving everyday tech problems—right where you need it. As a young, growing business, we’re dedicated to providing
            excellent service at fair, competitive rates—because building trust is at the core of everything we do.
          </p>
        </div>
      </div>
    </section>
  )
}
