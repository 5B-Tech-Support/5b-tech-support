
export default function ContactForm(){
  return (
    <section className="mt-24">
      <div className="container-5b max-w-4xl">
        <h2 className="text-3xl md:text-4xl font-semibold mb-10">Contact us</h2>
        <form className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
            <div>
              <label className="block text-sm mb-2">First name *</label>
              <input className="input" placeholder="" required />
            </div>
            <div>
              <label className="block text-sm mb-2">Last name</label>
              <input className="input" placeholder="" />
            </div>
          </div>
          <div>
            <label className="block text-sm mb-2">Email *</label>
            <input type="email" className="input" required />
          </div>
          <div>
            <label className="block text-sm mb-2">In which city are you located? *</label>
            <input className="input" required />
          </div>
          <div>
            <label className="block text-sm mb-2">Write a message *</label>
            <textarea className="input min-h-[120px]" required></textarea>
          </div>
          <div className="pt-4">
            <button type="button" className="primary">Submit</button>
            <p className="text-xs text-black/50 mt-3">Buttons are wired later — we’ll connect to email/Formspree.</p>
          </div>
        </form>
      </div>
    </section>
  )
}
