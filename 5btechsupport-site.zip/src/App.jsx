
import { Routes, Route } from 'react-router-dom'
import Home from './pages/Home.jsx'
import Pricing from './pages/Pricing.jsx'
import AboutPage from './pages/AboutPage.jsx'
import Book from './pages/Book.jsx'
import Header from './components/Header.jsx'
import Footer from './components/Footer.jsx'
import ReviewsBadge from './components/ReviewsBadge.jsx'

export default function App() {
  return (
    <div className="font-sans text-black">
      <Header />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/pricing" element={<Pricing />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/book" element={<Book />} />
      </Routes>
      <Footer />
      <ReviewsBadge />
    </div>
  )
}
