
export default function Book(){
  return (
    <main className="container-5b py-20">
      <h1 className="text-4xl font-bold mb-6">Book</h1>
      <p>We’ll integrate your booking flow here — e.g., Calendly or a simple email form. For now, this is a stub page.</p>
    </main>
  )
}
