
export default function Pricing(){
  return (
    <main className="container-5b py-20">
      <h1 className="text-4xl font-bold mb-6">Pricing</h1>
      <p>We’ll mirror your Wix pricing table here. Add your packages and rates, and we can make this page match exactly.</p>
    </main>
  )
}
