
export default function AboutPage(){
  return (
    <main className="container-5b py-20">
      <h1 className="text-4xl font-bold mb-6">About</h1>
      <p>Use this page for the full story, team photos, and values. The homepage has a condensed version.</p>
    </main>
  )
}
