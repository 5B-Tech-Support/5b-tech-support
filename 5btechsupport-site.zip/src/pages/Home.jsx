
import Hero from '../components/Hero.jsx'
import ContactForm from '../components/ContactForm.jsx'
import Mission from '../components/Mission.jsx'
import About from '../components/About.jsx'
import Services from '../components/Services.jsx'

export default function Home(){
  return (
    <main>
      <Hero />
      <ContactForm />
      <Mission />
      <About />
      <Services />
    </main>
  )
}
