
/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: '#6A3DF0',
          light: '#EDE7FF',
          dark: '#4E2ACC'
        }
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'ui-sans-serif', 'Segoe UI', 'Roboto', 'Helvetica', 'Arial', 'sans-serif'],
        display: ['Sora', 'Inter', 'ui-sans-serif']
      },
      boxShadow: {
        card: '0 6px 24px rgba(0,0,0,0.08)'
      }
    },
  },
  plugins: [],
}
