
# 5B Tech Support — Carbon Copy (React + Tailwind + Vite)

This project replicates your Wix homepage layout with React and Tailwind, ready to deploy free on GitHub Pages, Vercel, or Netlify.

## Quickstart

```bash
pnpm i # or npm i or yarn
pnpm dev # or npm run dev
```

## Build

```bash
pnpm build
```

## Deploy options

### Vercel (recommended)
- Import the repo to Vercel, framework preset: **Vite**.
- Build command: `vite build`. Output dir: `dist`.

### GitHub Pages
- Add package `gh-pages` and a deploy script if you want GH Pages. (Ask me and I’ll wire it.)

## Replacing assets

- **Logo**: Replace the text logo in `Header.jsx` with `src/assets/logo.svg` if you have one.
- **Photos**: Replace the placeholder URLs used in `About.jsx` with your own images (local files or hosted).
- **Background image**: The About section uses a stock mountains image; swap to your own.

## Form integration

The "Submit" button is a placeholder. We can connect it to Formspree, EmailJS, a serverless function, or Google Forms. Ping me when ready.

## Notes on spacing & typography

- Typography uses **Sora** (display) and **Inter**.
- Layout widths aim to visually match your screenshots (max content width ~1200px, large paddings like the Wix version).
- Fine spacing tweaks are easy — tell me what to adjust and I’ll give exact values.
